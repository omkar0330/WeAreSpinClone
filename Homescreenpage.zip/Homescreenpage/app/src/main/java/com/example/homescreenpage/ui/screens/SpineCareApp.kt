package com.example.homescreenpage.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.homescreenpage.R
import com.example.homescreenpage.ui.theme.GreenPrimary
import com.example.homescreenpage.ui.theme.OrangeAccent
import com.example.homescreenpage.ui.theme.White

@Composable
fun SpineCareApp(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // 1. Header Section
        item { HeaderSection() }

        // 2. Top Cards Section (Appointment Cards)
        item { AppointmentCards() }

        // 3. Second Section: DOCTORS
        item { SectionHeader("DOCTORS") }
        item { DoctorsList() }

        // 4. Third Section: YOUR PROFILE
        item { SectionHeader("YOUR PROFILE") }
        item { ProfileCard() }

        // 5. Fourth Section: COMMON SPINE ISSUES
        item { SectionHeader("COMMON SPINE ISSUES") }
        item { SpineIssuesList() }

        // Additional Card (Test Your Spine)
        item { TestYourSpineCard() }

        // 6. Fifth Section: Frequently Asked Questions
        item { SectionHeader("Frequently Asked Questions") }
        items(faqs) { faq ->
            FaqItem(faq)
        }

        // 7. Last Section: Stats Section (Patients, Surgery, Hospitals, Doctors)
        item { StatsSection() }

        item { Spacer(modifier = Modifier.height(32.dp)) }
    }
}

@Composable
fun TestYourSpineCard() {
    Card(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "TEST YOUR\nSPINE TODAY",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 22.sp,
                    lineHeight = 26.sp,
                    color = Color.Black
                )
                Text(
                    text = "ANYWHERE ANYTIME",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold
                )
            }
            Button(
                onClick = { },
                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
            ) {
                Text("Start Now", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
fun HeaderSection() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .background(
                color = GreenPrimary,
                shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
            )
            .padding(24.dp)
    ) {
        Column {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "The best\ncare for\nyour spine",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 34.sp
            )
        }
        Icon(
            imageVector = Icons.Default.AccountCircle,
            contentDescription = "Profile",
            tint = Color.White,
            modifier = Modifier
                .size(56.dp)
                .align(Alignment.TopEnd)
        )
    }
}

@Composable
fun AppointmentCards() {
    Row(
        modifier = Modifier
            .padding(horizontal = 16.dp)
            .offset(y = (-40).dp)
            .fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AppointmentCard(
            title = "Book In - clinic\nAppointment",
            modifier = Modifier.weight(1f),
            imageRes = R.drawable.cervical,
            onClick = { /* Handle Click */ }
        )
        AppointmentCard(
            title = "Video-Based\nAppointment",
            modifier = Modifier.weight(1f),
            imageRes = R.drawable.tumour,
            onClick = { /* Handle Click */ }
        )
    }
}

@Composable
fun AppointmentCard(title: String, modifier: Modifier, imageRes: Int, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = modifier,
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFE8F5E9)) // Light green background
            ) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    lineHeight = 16.sp
                )
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = GreenPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 24.dp, end = 16.dp, bottom = 12.dp),
        color = Color.Black
    )
}

@Composable
fun SpineIssuesList() {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SpineIssueCard("OSTEOARTHRITIS", R.drawable.ankylosing) }
        item { SpineIssueCard("CERVICAL SPONDYLOSIS", R.drawable.cervical) }
        item { SpineIssueCard("SPINE TUMOUR", R.drawable.tumour) }
    }
}

@Composable
fun SpineIssueCard(title: String, imageRes: Int) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.width(150.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, color = Color.Black)
            Spacer(modifier = Modifier.height(8.dp))
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
fun StatsSection() {
    Box(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(OrangeAccent)
            .padding(vertical = 32.dp, horizontal = 16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(32.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                StatItem(Icons.Default.Groups, "PATIENTS", "10 Lakhs")
                StatItem(Icons.AutoMirrored.Filled.Assignment, "SURGERY", "10 k+")
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                StatItem(Icons.Default.LocalHospital, "HOSPITALS", "5")
                StatItem(Icons.Default.Person, "DOCTORS", "6")
            }
        }
    }
}

@Composable
fun StatItem(icon: ImageVector, label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun FaqItem(question: String) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = question,
                modifier = Modifier.weight(1f),
                fontSize = 15.sp,
                color = Color.DarkGray,
                fontWeight = FontWeight.Medium
            )
            Icon(Icons.Default.ExpandMore, contentDescription = null, tint = Color.Gray)
        }
        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = Color(0xFFE0E0E0), thickness = 1.dp)
    }
}

@Composable
fun DoctorsList() {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { DoctorCard("DR. ABHAY NENE", "CONSULTANT SPINE SURGEON", R.drawable.doctor1) }
        item { DoctorCard("DR. PRIYANKA PATEL", "CONSULTANT SPINE SURGEON", R.drawable.doctor2) }
    }
}

@Composable
fun DoctorCard(name: String, specialty: String, imageRes: Int) {
    Card(
        modifier = Modifier.width(220.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF5F5F5))
            ) {
                Image(
                    painter = painterResource(imageRes),
                    contentDescription = name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = name,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color.Black
            )

            Text(
                text = specialty,
                fontSize = 10.sp,
                color = Color.Gray
            )
        }
    }
}


@Composable
fun ProfileCard() {
    Card(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE1F5FE)) // Light blue for contrast
    ) {
        Box(
            modifier = Modifier
                .padding(32.dp)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Button(
                onClick = { },
                colors = ButtonDefaults.buttonColors(containerColor = White),
                shape = RoundedCornerShape(8.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
            ) {
                Text("Login To Know Your Details", color = Color.DarkGray, fontWeight = FontWeight.Bold)
            }
        }
    }
}

val faqs = listOf(
    "What is the cause of Pot's disease?",
    "How do you confirm TB in the spine?",
    "What are discs in the spine?",
    "How do you treat a disc problem?",
    "Can a slipped disc be fixed?",
    "What are the symptoms of a bad disc?"
)
