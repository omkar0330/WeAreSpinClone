package com.example.homescreenpage.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF4CAF50)
val OrangeAccent = Color(0xFFFF9800)
val BlueBackground = Color(0xFFE3F2FD)
val White = Color(0xFFFFFFFF)
val GrayText = Color(0xFF757575)
val DividerColor = Color(0xFFBDBDBD)
